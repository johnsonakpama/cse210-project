using System;

class Program
{
     myName = "Johnson";

    var myDate = newDate();

    year = myDate. getYear();

    console.log(year);

    var myImage = "images/WIN_20210603_135914-Copy.JPG"

    var favoriteFood = ["potato","rice","yam"]

    console.log(favoriteFood)

    var favoriteFood = []

    favoriteFood.log(favoriteFood.add("bean"));

    console.log(favoriteFood)

    var favoriteFood = []

    favoriteFood.shift()

    console.log(favoriteFood)

    var favoriteFood = []
    
    favoriteFood.pop()

    console.log(favoriteFood)


    
} 